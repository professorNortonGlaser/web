package com.norton.backend;

import ch.qos.logback.core.net.server.Client;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/cliente")
public class ClienteController {
    ClienteService service = new ClienteService();

    @GetMapping
    public ResponseEntity<Cliente> carregar(){
        Cliente obj = new Cliente();
        try {
            obj.setCodigo(1);
            obj.setDocumento("234234");
            obj.setEmail("norton@norton.net.br");
            obj.setNome("Norton");
            obj.setTelefone("2344-2344");
            service.pesquisar();
            return ResponseEntity.ok(obj);
        }
        catch(Exception err){
            return (ResponseEntity<Cliente>) ResponseEntity.internalServerError();
        }
    }

    @PostMapping
    public ResponseEntity<String> gravar(@RequestBody Cliente obj){
        String msg = "Cliente "+ obj.getCodigo() + " gravado com sucesso !";
        service.gravar();
        return ResponseEntity.ok(msg);
    }

}

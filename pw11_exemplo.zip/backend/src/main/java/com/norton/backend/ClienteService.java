package com.norton.backend;

import org.springframework.stereotype.Service;

@Service
public class ClienteService {
    public void gravar(){

    }

    public void pesquisar(){

    }
}

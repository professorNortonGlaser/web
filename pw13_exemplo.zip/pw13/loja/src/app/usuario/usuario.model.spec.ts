import { UsuarioModel } from './usuario.model';

describe('UsuarioModel', () => {
  it('should create an instance', () => {
    expect(new UsuarioModel()).toBeTruthy();
  });
});

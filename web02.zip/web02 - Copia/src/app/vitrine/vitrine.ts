import { Component } from '@angular/core';

@Component({
  selector: 'app-vitrine',
  imports: [],
  templateUrl: './vitrine.html',
  styleUrl: './vitrine.css',
})
export class Vitrine {

}

import { Component, signal } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { Bemvindo } from './bemvindo/bemvindo';

@Component({
  selector: 'app-root',
  imports: [RouterOutlet, Bemvindo],
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App {
  protected readonly title = signal('web02');
}

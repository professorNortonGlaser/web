import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Produto } from '../model/produto';
import { ItemCesta } from '../model/item-cesta';

@Component({
  selector: 'app-cesta',
  imports: [CommonModule],
  templateUrl: './cesta.html',
  styleUrl: './cesta.css',
})
export class Cesta {
  mensagem: String = "";
  lista: ItemCesta[] = [];
  total: number = 0;

  ngOnInit(){
    let json = localStorage.getItem("cesta");
    if(json==null){
      this.mensagem = "Sua cesta esta vazia!!!";
    } else {
      this.lista = JSON.parse(json);
      this.calculaTotal();
    }
  }

  calculaTotal(){
    this.total = 0
    for(let obj of this.lista){
      this.total = this.total + obj.valor;
    }
  }
}

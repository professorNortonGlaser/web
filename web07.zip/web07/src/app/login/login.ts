import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Cliente } from '../model/cliente';

@Component({
  selector: 'app-login',
  imports: [CommonModule, FormsModule],
  templateUrl: './login.html',
  styleUrl: './login.css',
})
export class Login {
    mensagem: string = "";
    obj: Cliente = new Cliente();

    fazerLogin(){
      if(this.obj.email=="norton@norton.net.br" && this.obj.senha=="123456"){
        this.obj.nome = "norton";
        this.obj.logradouro = "Rua frei joao, 59 são paulo, sp";
        this.obj.telefone = "11 3244-2344";
        localStorage.setItem("Cliente", JSON.stringify(this.obj));
        location.href = "cadastro";
      } else {
        this.mensagem = "Email ou senha incorretos!";
      }
    }

      novoCadastro(){
        localStorage.removeItem("Cliente");
        location.href = "cadastro";  
      }
}

import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Cliente } from '../model/cliente';
@Component({
  selector: 'app-recupera',
  imports: [CommonModule, FormsModule],
  templateUrl: './recupera.html',
  styleUrl: './recupera.css',
})
export class Recupera {
  mensagem: string = "";
  obj: Cliente = new Cliente();

  recuperarSenha(){
      this.mensagem = "Um e-mail com as instruções de recuperação de senha foi enviado!";
  }


}
